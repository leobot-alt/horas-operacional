-- Estrutura inicial para migrar o armazenamento local para Supabase.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  role text not null default 'viewer' check (role in ('admin','editor','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.operations (
  id uuid primary key default gen_random_uuid(),
  name text not null, type text not null default 'horas', schedule text, leader text, subleader text,
  ceilings jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create table if not exists public.blocks (
  id uuid primary key default gen_random_uuid(),
  operation_id uuid not null references public.operations(id) on delete cascade,
  name text not null, profile text not null, rate numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.monthly_hours (
  id uuid primary key default gen_random_uuid(),
  block_id uuid not null references public.blocks(id) on delete cascade,
  year integer not null, month integer not null check (month between 1 and 12),
  hours numeric(12,2) not null default 0,
  updated_at timestamptz not null default now(),
  unique(block_id, year, month)
);

alter table public.profiles enable row level security;
alter table public.operations enable row level security;
alter table public.blocks enable row level security;
alter table public.monthly_hours enable row level security;
